"""One routing job from the board's point of view: read, route, apply, and
escalate on what failed. Shared by the dialog, the AI assistant and the
headless tests so they all behave the same.

Escalation: connections the first pass could not route are tried again on a
finer grid (half the pitch), at the neck width, with cheaper vias, in a run
scoped to just those nets. That is what a designer does by hand for the last
few stubborn connections, and what the AI assistant found by itself.
"""
import copy
from collections import Counter
from dataclasses import dataclass, field
from typing import Callable, List, Optional

import pcbnew

from . import apply as native_apply, astar as native_astar, extract as native_extract, router as native_router, tuning as native_tuning
from .problem import NativeOptions, SCOPE_SELECTION

_REMOVED: list = []        # board items taken off headless; Python must not free them


@dataclass
class JobResult:
    routed: int = 0
    failed: List[str] = field(default_factory=list)       # net names still open
    failed_detail: List[dict] = field(default_factory=list)
    ripped: int = 0
    shoved: int = 0                 # existing board tracks moved out of the way (shove mode)
    fanout: int = 0
    pairs: int = 0
    pair_swaps: int = 0             # of those, coupled with a via swap
    pair_vias: int = 0              # via pairs where coupled runs change layers
    stitched: int = 0
    pair_log: List[tuple] = field(default_factory=list)
    escalated: int = 0                                     # connections saved by the second pass
    passes: int = 1
    seconds: float = 0.0
    stats: dict = field(default_factory=dict)
    layers: list = field(default_factory=list)
    cancelled: bool = False
    timed_out: bool = False                                # the time limit cut a pass short
    tuning: List[dict] = field(default_factory=list)       # length groups: target, lengths before/after
    tuning_lines: List[str] = field(default_factory=list)
    pair_exceptions: List[dict] = field(default_factory=list)   # pairs connected directly, and why
    pair_loose: List[dict] = field(default_factory=list)        # pairs coupled but finished single-ended at one end


# Of the time limit; the finer second pass gets the rest. The rip-up rounds
# of the first pass close more of the last few opens than the finer grid
# does (its failures are capped open searches): on a CM5 whose outward pair
# fans wall in row pins, rip-up round 2 routes I2C_SDA/SCL once it has the
# budget, while a pass cut at 0.7 of a slower work rate left both to the
# finer pass, which joined neither. 0.15 still gives that pass 90 s of 10 min.
FIRST_PASS_SHARE = 0.85


def fine_options(options: NativeOptions, failed_nets: List[str], board) -> NativeOptions:
    """The second pass's options: half the pitch, the neck width, cheaper
    vias, scoped to the open nets, no more pour vias."""
    fine = copy.deepcopy(options)
    fine.pitch_mm = max(0.025, options.pitch_mm / 2)
    fine.via_cost = max(5, options.via_cost // 3)
    fine.max_expansions = options.max_expansions * 3
    fine.scope, fine.scope_nets, fine.scope_refs = SCOPE_SELECTION, list(failed_nets), []
    fine.fanout_vias = False
    fine.dual_escapes = True       # leave a stubborn pad by either end, whichever the search finds open
    fine.stitch_vias = False
    fine.rip_rounds = max(fine.rip_rounds, 12)
    fine.rip_limit = max(fine.rip_limit, 8)
    # the first pass's tracks are board copper now: let this pass rip up the
    # ones that wall a stubborn connection in and reroute them (shove mode)
    fine.shove = options.fine_shove
    # the stubborn ones go at the neck width for their whole length
    sizes = native_extract.board_sizes(board)
    narrow = [w for w in sizes["track_widths"] if w >= sizes["min_track_width"]]
    if narrow:
        fine.track_mode, fine.track_width = "fixed", min(narrow)
    return fine


def run_job(board, options: NativeOptions, status=None, progress=None, on_path=None, on_remove=None,
            cancelled: Optional[Callable[[], bool]] = None, escalate: bool = True,
            apply_paths: bool = True, extract_fn=None, on_layers=None, placed=None, on_board=None) -> JobResult:
    """The whole job, in the order a designer works:
      1. signals at the normal grid (pour vias held back);
      2. a finer second pass on what is still open;
      3. the pours: fanout vias, ties and stitching in the room that is left.
    When apply_paths is False the caller adds paths itself through on_path
    (the dialog does, for live display); extract_fn lets the caller run the
    board reads on its UI thread; on_layers is told the layer list of each
    pass before its paths arrive; placed (with apply_paths False) returns the
    UUIDs of the items the caller has put on the board for this job so far,
    so a later pass may move the job's own plane vias as it does otherwise;
    on_board runs a function on the thread that owns the board and returns
    its result (the dialog's UI thread; called directly when None)."""
    extract = extract_fn or (lambda b, o, st: native_extract.extract(b, o, status=st))
    out = JobResult()
    added: list = []                       # board items this job created (apply_paths)
    paired_items: list = []                # ...of which the coupled pairs' lines
    job_started = native_astar.clock()        # the wall clock, or the search work done (benchmarks)
    limit = options.time_limit_s if options.time_limit_s and options.time_limit_s > 0 else 0.0

    def job_items() -> list:
        """UUIDs of the items this job has on the board now (ripped ones gone)."""
        if not apply_paths:
            return list(placed()) if placed else []
        gone = {str(item.m_Uuid.AsString()) for item in _REMOVED}
        return [u for u in (str(item.m_Uuid.AsString()) for item in added) if u not in gone]

    def remaining() -> float:
        """Seconds left of the job's time limit (0 = no limit)."""
        return max(0.0, limit - (native_astar.clock() - job_started)) if limit else 0.0

    def one_pass(opts: NativeOptions):
        problem = extract(board, opts, status)
        if problem is None:
            return None, None
        if on_layers:
            on_layers(problem.layers)
        movable = {ex.path.pid: list(ex.items) for ex in problem.existing}

        def remove(pid):
            # shove mode: a board piece ripped up comes off the board (the
            # caller does it itself when it places paths live)
            if apply_paths:
                for item in movable.pop(pid, []):
                    if native_router._DEBUG:
                        print(f"[remove] pid {pid} {item.GetClass()} {item.GetNetname()} at "
                              f"{item.GetPosition().x / 1e6:.2f},{item.GetPosition().y / 1e6:.2f}", flush=True)
                    try:
                        board.Remove(item)
                        item.thisown = 0
                        _REMOVED.append(item)
                    except Exception:
                        pass
            if on_remove:
                on_remove(pid)

        result = native_router.run(problem, progress=progress, on_path=on_path, on_remove=remove,
                                   cancelled=cancelled)
        if apply_paths:
            paired = getattr(result, "paired_pids", set())
            for rp in result.paths:
                items = native_apply.add_path(board, problem.layers, rp)
                added.extend(items)
                if rp.pid in paired:
                    paired_items.extend(items)       # a coupled pair's lines: no later pass moves them
            if result.shoved:
                try:
                    board.BuildConnectivity()
                except Exception:
                    pass
        return problem, result

    pours_later = options.fanout_vias or options.stitch_vias
    if options.fanout_vias and options.fanout_first and not options.pours_only:
        # Pad vias of the plane nets first, as a designer drops the decoupling
        # vias before routing signals: the pins keep their outlets (via guards)
        # and the signals route around the vias instead of walling them off.
        if status:
            status("Plane nets: pad vias before the signals...")
        early = copy.deepcopy(options)
        early.pours_only = True
        early.stitch_vias = False
        early.time_limit_s = 0
        try:
            problem0, result0 = one_pass(early)
        except Exception as e:
            out.stats["fanout_error"] = str(e)
            problem0 = None
        if problem0 is not None:
            out.fanout += result0.fanout
            out.seconds += result0.seconds
            # the sides the pads were left by, decided before those vias existed
            options = copy.copy(options)
            options.escape_sides = dict(problem0.escape_sides)
            # those vias are the job's own: a signal pass may rip one up that
            # walls in a connection, and the pour pass drops it again if room is left
            options.movable_uuids = job_items()
    first = copy.deepcopy(options)
    if pours_later:
        first.fanout_vias = False
        first.stitch_vias = False
    if limit:
        # the first pass leaves the finer second pass its share of the time:
        # once the first pass is down to rip-up rounds that gain a connection
        # a minute, the finer grid (neck width, cheaper vias, shove) does
        # better with the same minutes on what is still open
        share = FIRST_PASS_SHARE if escalate and options.pitch_mm > 0.04 else 1.0
        first.time_limit_s = max(1.0, remaining() * share)
    problem, result = one_pass(first)
    if problem is None:
        return out
    out.layers = problem.layers
    out.stats = dict(problem.stats)
    out.routed, out.ripped, out.pairs = result.routed, result.ripped, result.pairs
    out.shoved = result.shoved
    out.pair_swaps = getattr(result, "pair_swaps", 0)
    out.pair_vias = getattr(result, "pair_vias", 0)
    out.pair_log = list(getattr(result, "pair_log", []))
    out.failed_detail = list(getattr(result, "failed_detail", []))
    out.seconds = result.seconds
    out.cancelled = result.cancelled
    out.timed_out = result.timed_out
    out.failed = sorted({problem.nets[c.net].name for c in result.failed})
    out.pair_exceptions = list(getattr(result, "pair_exceptions", []))
    out.pair_loose = list(getattr(result, "pair_loose", []))
    out.stats["budget_cuts"] = getattr(result, "budget_cuts", 0)
    if options.movable_uuids and (apply_paths or placed):
        # the plane vias as they stand now (ripped ones gone, restored ones in)
        options = copy.copy(options)
        options.movable_uuids = job_items()

    # the finer pass needs room in the time limit (its board read alone takes a while)
    time_for_more = not limit or remaining() > 60.0
    if not time_for_more:
        out.timed_out = True
        if status:
            status("Time limit reached: no finer second pass.")
    if escalate and out.failed and not out.cancelled and time_for_more and options.pitch_mm > 0.04 \
            and not (cancelled and cancelled()):
        if status:
            status(f"Second pass on {len(out.failed)} open connection(s): finer grid, neck width, cheaper vias...")
        fine = fine_options(options, out.failed, board)
        fine.locked_uuids = list(options.locked_uuids) + [str(item.m_Uuid.AsString()) for item in paired_items]
        # the finer grid is four times the cells: a stubborn connection could
        # search for minutes there, so the pass gets its own budget
        budget = options.fine_budget_s
        if budget is None:
            budget = 60.0 + 20.0 * len(out.failed)
        if budget and limit:
            fine.time_limit_s = min(budget, max(1.0, remaining()))
        elif limit:
            fine.time_limit_s = max(1.0, remaining())
        else:
            fine.time_limit_s = budget or 0
        try:
            problem2, result2 = one_pass(fine)
        except Exception as e:
            out.stats["escalation_error"] = str(e)
            problem2 = None
        if problem2 is not None and problem2.connections:
            out.passes = 2
            out.escalated = result2.routed
            out.stats["budget_cuts"] += getattr(result2, "budget_cuts", 0)
            out.routed += result2.routed
            out.ripped += result2.ripped
            out.shoved += result2.shoved
            out.seconds += result2.seconds
            out.failed = sorted({problem2.nets[c.net].name for c in result2.failed})
            out.failed_detail = list(getattr(result2, "failed_detail", []))
            # the finer pass running out of its own budget is not the job's
            # time limit: only report that when the job's limit was what ended it
            if result2.timed_out and limit and remaining() <= 1.0:
                out.timed_out = True

    # Routes that ended on their net's pour rather than at a pad: the pour
    # was the one filled before this run, and a route of another net laid
    # across it since (or the refill pulling back from the new copper) can
    # leave such an end in a piece the pads are no longer in. Refill, and
    # route what came apart again, pad to pad this time.
    joins = {name: info for name, info in problem.stats.get("pour_joins", {}).items() if name not in out.failed}
    if joins and (apply_paths or on_path) and not out.cancelled and not (cancelled and cancelled()):
        try:
            check = lambda: _open_pour_joins(board, joins, result)
            apart = on_board(check) if on_board else check()
        except Exception as e:
            out.stats["pour_check_error"] = repr(e)
            apart = []
        if apart:
            if status:
                status(f"{len(apart)} net(s) came apart from their pour at a route's end: routing them pad to pad...")
            again = copy.deepcopy(options)
            again.pour_goals = False
            again.scope, again.scope_nets, again.scope_refs = SCOPE_SELECTION, list(apart), []
            again.fanout_vias = False
            again.stitch_vias = False
            again.time_limit_s = max(1.0, min(60.0, remaining())) if limit else 60.0
            try:
                problem5, result5 = one_pass(again)
            except Exception as e:
                out.stats["pour_check_error"] = repr(e)
                problem5 = None
            if problem5 is not None:
                out.stats["pour_joins_redone"] = result5.routed
                out.routed += result5.routed
                out.seconds += result5.seconds
                out.failed = sorted(set(out.failed) | {problem5.nets[c.net].name for c in result5.failed})

    problem3 = None
    if pours_later and not (cancelled and cancelled()):
        if status:
            status("Pour nets: fanout vias, ties and stitching in the remaining room...")
        pours = copy.deepcopy(options)
        pours.pours_only = True                       # same scope, no signal routing
        pours.time_limit_s = 0                        # the pour stages are bounded; always finish them
        pours.movable_uuids = []                      # nothing is ripped up here: the vias are fixed copper again
        try:
            problem3, result3 = one_pass(pours)
        except Exception as e:
            out.stats["pour_error"] = str(e)
            problem3 = None
        if problem3 is not None:
            out.fanout += result3.fanout
            out.stitched = result3.stitched
            out.seconds += result3.seconds
    # Signal rerouting as well as power repairs can split surface copper.
    # Refill once more and reconnect isolated islands; extraction returns
    # immediately when there are no stitch candidates.
    if (pours_later and problem3 is not None and options.stitch_vias
            and not (cancelled and cancelled())):
        islands = copy.deepcopy(options)
        islands.pours_only = True
        islands.repair_islands_only = True
        islands.fanout_vias = False
        islands.stitch_vias = False
        islands.movable_uuids = []
        islands.time_limit_s = 0
        if status:
            status("Checking repaired pours for isolated copper...")
        problem4, result4 = one_pass(islands)
        if problem4 is not None:
            out.stitched += result4.stitched
            out.seconds += result4.seconds
    if apply_paths and added:
        # SWIG wrappers do not compare by item: tell the ripped-up ones apart by UUID
        gone = {str(item.m_Uuid.AsString()) for item in _REMOVED}
        live = [t for t in added if str(t.m_Uuid.AsString()) not in gone]
        out.stats.update(finish_copper(board, live, options, cancelled))
    if apply_paths and not (cancelled and cancelled()):
        report = tune_lengths(board, options, status, out.pair_exceptions)
        if report is not None:
            out.tuning, out.tuning_lines = report.groups, report.lines()
    return out


def _open_pour_joins(board, joins: dict, result) -> List[str]:
    """Of the nets whose routes may have ended on their pour (extract's
    "pour_joins": pad groups before the run, connections in all and in
    scope), those the refilled board has in more groups than the routed
    connections leave."""
    pcbnew.ZONE_FILLER(board).Fill(board.Zones())
    board.BuildConnectivity()
    conn = board.GetConnectivity()
    failed = Counter(c.net for c in result.failed)
    out = []
    for name, info in joins.items():
        net = board.FindNet(name)
        if net is None:
            continue
        code = net.GetNetCode()
        if info["route"]:
            # a routed net: known only when all of it was this job's to join
            if info["scoped"] != info["all"] or failed[code]:
                continue
            expected = 1
        else:
            # a plane net: each routed stray is one group fewer
            expected = info["groups"] - (info["scoped"] - failed[code])
        if len(native_apply._pad_groups(board, conn, code)) > max(1, expected):
            out.append(name)
    return out


def finish_copper(board, live: list, options: NativeOptions, cancelled=None) -> dict:
    """The clean-up of a run's copper once nothing will be ripped up any
    more, the same whether the pipeline placed the paths or the dialog did
    (live display): shared copper written once, tiny off-angle joins snapped,
    vias that join nothing taken off with the stubs that led to them, every
    junction welded into a shared end point, power rails widened where there
    is room, pour islands the copper cut off tied back to their net. live: the items the run created that
    are still on the board. Returns counts (and *_error entries)."""
    stats: dict = {}

    def alive(items):
        gone = {str(item.m_Uuid.AsString()) for item in native_apply._REMOVED}
        return [t for t in items if str(t.m_Uuid.AsString()) not in gone]

    stats["trimmed"] = native_apply.trim_overlaps(board, live)
    try:
        # tiny odd-angle joins where a run ends off the grid: the 45-degree
        # segments either side meet directly instead
        stats["tiny_joins_snapped"] = native_apply.snap_tiny_joins(board, alive(live))
    except Exception as e:
        stats["snap_error"] = repr(e)
    if cancelled and cancelled():
        return stats
    # vias that ended up joining nothing (a pad via that missed the plane's
    # fill, a fanout via a route made unnecessary): off the board
    live = alive(live)
    try:
        stats["dangling_vias_removed"] = native_apply.prune_dangling_vias(board, live)
    except Exception as e:
        stats["prune_error"] = repr(e)
    # every junction of the run's copper a shared end point (via centres,
    # T points split), the way KiCad's own router leaves it
    try:
        live[:] = alive(live)
        welded = native_apply.weld_junctions(board, live)
        stats["welded"] = sum(welded.values())
        stats["weld_detail"] = welded
    except Exception as e:                     # cosmetic: never lose a routed board over it
        stats["weld_error"] = repr(e)
    # power rails: as wide as the finished board leaves room for
    try:
        stats["power_widened"] = native_apply.widen_power(board, alive(live), options.power_patterns)
    except Exception as e:
        stats["widen_error"] = repr(e)
    if cancelled and cancelled():
        return stats
    # pieces of a pour that the finished copper cut off with only their own
    # pads in them: a stub and via to the net's connected fill
    try:
        stats["islands_joined"] = native_apply.repair_islands(board, live, cancelled=cancelled)
    except Exception as e:
        stats["island_error"] = repr(e)
    return stats


def waived_skew(board, options: NativeOptions, pair_exceptions) -> set:
    """Nets of pairs whose skew does not matter: the router waived their
    coupling as unnecessary and the whole pair is no longer than the
    uncoupled length allowed (a pair's few millimetres between a connector
    and its ESD part). Marks those exceptions with "skew_waived"."""
    out = set()
    by_name = {n.GetNetname(): c for c, n in board.GetNetsByNetcode().items() if c > 0}
    lengths = native_tuning.track_lengths(board)
    limit = options.pair_uncoupled_max_mm * 1_000_000
    for e in pair_exceptions or []:
        longest = max(lengths.get(by_name.get(n, -1), 0) for n in e["nets"])
        e["skew_waived"] = bool(e.get("exempt_skew") and longest <= limit)
        if e["skew_waived"]:
            out |= set(e["nets"])
    return out


def tune_lengths(board, options: NativeOptions, status=None, pair_exceptions=None):
    """Length matching after routing (and after the overlap merge): the
    options' length groups get meanders, wrapped in KiCad tuning patterns.
    A pair whose coupling the router waived as unnecessary (ends too close)
    is not skew-tuned either. None when there is nothing to tune. Main thread
    only (it edits the board)."""
    if not options.tune_lengths or not options.length_groups:
        return None
    waived = waived_skew(board, options, pair_exceptions)
    groups = [g for g in options.length_groups if not (g.get("pair") and set(g["nets"]) & waived)]
    if not groups:
        return None
    try:
        report = native_tuning.tune(board, groups, status=status, removed_sink=_REMOVED,
                                    kicad_patterns=options.kicad_tuning_patterns,
                                    rounded=getattr(options, "tune_rounded", True))
    except Exception as e:
        if status:
            status(f"Length matching failed: {e!r}")
        return None
    if status:
        for line in report.lines():
            status("Length matching: " + line)
    return report
