"""Routing every connection of a RoutingProblem, with rip-up and reroute.

Runs on a worker thread; it never touches pcbnew. Progress, each routed path
and each ripped-up path go out through callbacks (the dialog marshals them to
the UI thread and keeps the board in step).

Order of work:
  1. every connection, shortest first, with a plain A*;
  2. for each failed connection, a "soft" A* that may cross other routed
     paths at a penalty; the paths it crosses are ripped up, the connection
     is routed for real, and the ripped paths are rerouted (they may end up
     elsewhere, or fail and get their own turn in the next round);
  3. a last pass over whatever is still open with a bigger budget and cheaper
     vias.
Fixed copper (pads, pre-existing tracks, keepouts, escape stubs) is never
ripped up; only paths this run created are.
"""
import math
import time
from array import array
from typing import Callable, Dict, List, Optional, Set, Tuple

from . import astar
from .grid import BLOCKED, Grid
from .problem import Connection, NetInfo, RoutedPath, RoutingProblem

ProgressFn = Callable[[int, int, int, int, str], None]    # done, total, routed, failed, net name
PathFn = Callable[[RoutedPath], None]
RemoveFn = Callable[[int], None]                            # path id
RIP_PENALTY = 400                                           # per cell, in cost units (40 straight cells)
MAX_BLOCKERS = 10


class RouteResult:
    def __init__(self):
        self.routed = 0
        self.failed: List[Connection] = []
        self.paths: List[RoutedPath] = []
        self.ripped = 0
        self.fanout = 0
        self.pairs = 0
        self.stitched = 0
        self.failed_detail: List[dict] = []
        self.seconds = 0.0
        self.cancelled = False


class _Path:
    """A routed connection and everything needed to undo it."""
    def __init__(self, pid: int, conn: Connection, path: RoutedPath, cells: List[int], paired: bool = False):
        self.pid, self.conn, self.path, self.cells = pid, conn, path, cells
        self.claims: Dict[Tuple[int, int], List[int]] = {}      # owner-map key -> claimed cells
        self.via_cells: List[int] = []
        self.paired = paired                                   # half of a coupled pair: never ripped up


def _segment_distance(a, b) -> float:
    """Shortest distance between two segments (x1, y1, x2, y2)."""
    def seg_point(x1, y1, x2, y2, px, py):
        dx, dy = x2 - x1, y2 - y1
        l2 = dx * dx + dy * dy
        t = 0.0 if l2 == 0 else max(0.0, min(1.0, ((px - x1) * dx + (py - y1) * dy) / l2))
        return math.hypot(px - (x1 + t * dx), py - (y1 + t * dy))

    def cross(ox, oy, ax, ay, bx, by):
        return (ax - ox) * (by - oy) - (ay - oy) * (bx - ox)

    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    d1 = cross(ax1, ay1, ax2, ay2, bx1, by1)
    d2 = cross(ax1, ay1, ax2, ay2, bx2, by2)
    d3 = cross(bx1, by1, bx2, by2, ax1, ay1)
    d4 = cross(bx1, by1, bx2, by2, ax2, ay2)
    if ((d1 > 0) != (d2 > 0)) and ((d3 > 0) != (d4 > 0)) and d1 and d2 and d3 and d4:
        return 0.0
    return min(seg_point(ax1, ay1, ax2, ay2, bx1, by1), seg_point(ax1, ay1, ax2, ay2, bx2, by2),
               seg_point(bx1, by1, bx2, by2, ax1, ay1), seg_point(bx1, by1, bx2, by2, ax2, ay2))


def _offset_polyline(points: List[Tuple[int, int]], d: float, side: int) -> List[Tuple[int, int]]:
    """A polyline shifted sideways by d (mitred corners), to one side."""
    n = len(points)
    if n < 2:
        return list(points)
    normals = []
    for i in range(n - 1):
        ux, uy = points[i + 1][0] - points[i][0], points[i + 1][1] - points[i][1]
        length = math.hypot(ux, uy) or 1.0
        normals.append((-uy / length * side, ux / length * side))
    out = []
    for i in range(n):
        if i == 0:
            nx, ny = normals[0]
            scale = d
        elif i == n - 1:
            nx, ny = normals[-1]
            scale = d
        else:
            ax, ay = normals[i - 1]
            bx, by = normals[i]
            mx, my = ax + bx, ay + by
            m = math.hypot(mx, my)
            if m < 1e-9:                                  # a U-turn: fall back to the next normal
                nx, ny, scale = bx, by, d
            else:
                nx, ny = mx / m, my / m
                scale = d / max(0.3, nx * bx + ny * by)   # mitre, capped for very sharp corners
        out.append((int(round(points[i][0] + nx * scale)), int(round(points[i][1] + ny * scale))))
    return out


def _two_piece(grid: Grid, a: int, b: int, passable) -> Optional[List[int]]:
    """Cells of an octilinear two-piece path from cell a to cell b on one
    layer (a diagonal run and a straight run, either order), or None if any
    cell is blocked or a diagonal step would cut a corner."""
    plane, w = grid.plane, grid.w
    layer = a // plane
    ax, ay = a % w, (a % plane) // w
    bx, by = b % w, (b % plane) // w
    dx, dy = bx - ax, by - ay
    sx = (dx > 0) - (dx < 0)
    sy = (dy > 0) - (dy < 0)
    ndiag = min(abs(dx), abs(dy))
    nstraight = abs(dx) - ndiag if abs(dx) > abs(dy) else abs(dy) - ndiag
    diag = (sx, sy)
    straight = (sx, 0) if abs(dx) > abs(dy) else (0, sy)
    for order in ((diag, ndiag, straight, nstraight), (straight, nstraight, diag, ndiag)):
        d1, n1, d2, n2 = order
        x, y = ax, ay
        cells = []
        ok = True
        for d, n in ((d1, n1), (d2, n2)):
            for _ in range(n):
                nx, ny = x + d[0], y + d[1]
                idx = layer * plane + ny * w + nx
                if not passable(idx):
                    ok = False
                    break
                if d[0] and d[1] and not (passable(layer * plane + y * w + nx) and
                                          passable(layer * plane + ny * w + x)):
                    ok = False
                    break
                cells.append(idx)
                x, y = nx, ny
            if not ok:
                break
        if ok:
            return cells
    return None


def _smooth(grid: Grid, cells: List[int], passable) -> List[int]:
    """Straighten a cell path the way a designer would redraw it: from each
    point, jump as far ahead as a two-piece octilinear path (one straight run
    and one diagonal run) can reach through free cells, so wiggles and
    staircases collapse into at most two segments. Layer changes are kept
    where they are; only runs on a single layer are rewritten."""
    plane = grid.plane
    n = len(cells)
    if n < 3:
        return cells
    out = [cells[0]]
    i = 0
    while i < n - 1:
        layer = cells[i] // plane
        # the last index of this layer run
        end = i
        while end + 1 < n and cells[end + 1] // plane == layer:
            end += 1
        if end == i:                                   # a via step: keep it
            out.append(cells[i + 1])
            i += 1
            continue
        # farthest j reachable with a two-piece path (binary search is unsafe,
        # reachability is not monotone, so walk back from the end)
        j = end
        replaced = None
        while j > i + 1:
            replaced = _two_piece(grid, cells[i], cells[j], passable)
            if replaced is not None:
                break
            j -= 1
        if replaced is None:
            out.append(cells[i + 1])
            i += 1
        else:
            out.extend(replaced)
            i = j
    return out


def _simplify(grid: Grid, cells: List[int]):
    """Cell path -> straight segments per layer plus via positions."""
    points = [grid.unpack(i) for i in cells]
    segments, vias = [], []
    i, n = 0, len(points)
    while i < n - 1:
        layer, x0, y0 = points[i]
        j = i + 1
        if points[j][0] != layer:
            vias.append((grid.nm_x(x0), grid.nm_y(y0)))
            i = j
            continue
        dx, dy = points[j][1] - x0, points[j][2] - y0
        while j + 1 < n and points[j + 1][0] == layer and \
                (points[j + 1][1] - points[j][1], points[j + 1][2] - points[j][2]) == (dx, dy):
            j += 1
        _, x1, y1 = points[j]
        segments.append((layer, grid.nm_x(x0), grid.nm_y(y0), grid.nm_x(x1), grid.nm_y(y1)))
        i = j
    return segments, vias


def _with_pad_entries(grid: Grid, net: NetInfo, cells: List[int], segments):
    """Extend a cell path at both ends: grid cell -> exit point -> pad centre,
    when the end cell is a pad endpoint of this net."""
    out = list(segments)
    for cell, at_start in ((cells[0], True), (cells[-1], False)):
        entry = net.endpoints.get(cell)
        if entry is None:
            continue
        ex, ey, px, py, width = entry
        layer, cx, cy = grid.unpack(cell)
        gx, gy = grid.nm_x(cx), grid.nm_y(cy)
        extra = []
        if (gx, gy) != (ex, ey):
            extra.append((layer, gx, gy, ex, ey, width))
        if (ex, ey) != (px, py):
            extra.append((layer, ex, ey, px, py, width))
        if at_start:
            out = [(l, x2, y2, x1, y1, w) for l, x1, y1, x2, y2, w in reversed(extra)] + out
        else:
            out = out + extra
    return _merge_collinear(out)


def _merge_collinear(segments):
    """Join consecutive segments that continue in the same direction on the
    same layer with the same width (a stub running straight into its route)."""
    merged = []
    for seg in segments:
        if merged:
            prev = merged[-1]
            if (prev[0] == seg[0] and (prev[3], prev[4]) == (seg[1], seg[2])
                    and tuple(prev[5:]) == tuple(seg[5:])):
                ax, ay = prev[3] - prev[1], prev[4] - prev[2]
                bx, by = seg[3] - seg[1], seg[4] - seg[2]
                if ax * by - ay * bx == 0 and ax * bx + ay * by > 0:
                    merged[-1] = tuple(prev[:3]) + (seg[3], seg[4]) + tuple(prev[5:])
                    continue
        merged.append(seg)
    return merged


class Router:
    def __init__(self, problem: RoutingProblem):
        self.p = problem
        self.grid = problem.grid
        self.opts = problem.options
        self.horizontal = [l.horizontal for l in problem.layers]
        self.routable = [l.routable for l in problem.layers]
        # fixed copper as read from the board; the live maps start as copies
        self.fixed = {key: array("i", own) for key, own in problem.owners.items()}
        self.fixed_via_block = bytearray(problem.via_block)
        # cell -> path id, per owner map, for cells whose owner is routed copper
        self.routed = {key: array("i", [0]) * self.grid.size for key in problem.owners}
        self.paths: Dict[int, _Path] = {}
        self.next_pid = 1
        self.rips: Dict[Tuple[int, int, int], int] = {}        # (net, a, b) -> times ripped
        # union-find over each net's initial clusters, joined by surviving paths
        self.parent: Dict[int, List[int]] = {code: list(range(len(n.clusters)))
                                             for code, n in problem.nets.items()}

    # ---- clusters -------------------------------------------------------

    def _find(self, code: int, i: int) -> int:
        parent = self.parent[code]
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def _rebuild_union(self, code: int) -> None:
        self.parent[code] = list(range(len(self.p.nets[code].clusters)))
        for path in self.paths.values():
            if path.conn.net == code:
                self.parent[code][self._find(code, path.conn.a)] = self._find(code, path.conn.b)

    def _component(self, code: int, i: int) -> Tuple[Set[int], List[Tuple[int, int]]]:
        """All cells and anchors a route may start from / end on for the
        component holding initial cluster i."""
        net = self.p.nets[code]
        root = self._find(code, i)
        cells: Set[int] = set()
        anchors: List[Tuple[int, int]] = []
        for j, cl in enumerate(net.clusters):
            if self._find(code, j) == root:
                cells |= cl.cells
                anchors += cl.anchors
        for path in self.paths.values():
            if path.conn.net == code and self._find(code, path.conn.a) == root:
                cells.update(path.cells)
        return cells, anchors

    # ---- claims -----------------------------------------------------------

    def _claim(self, path: _Path) -> None:
        """Make a path's copper an obstacle (and remember what it claimed)."""
        grid, p, net = self.grid, self.p, self.p.nets[path.conn.net]
        rp = path.path
        for key, owners in p.owners.items():
            width, clearance = key
            cells: List[int] = []
            for seg in rp.segments:
                layer, x1, y1, x2, y2 = seg[:5]
                seg_w = seg[5] if len(seg) > 5 else rp.width
                r = seg_w // 2 + max(clearance, net.rules.clearance) + width // 2 + p.safety
                cells += grid.segment_cells(layer, x1, y1, x2, y2, r)
            r_via = rp.via_diameter // 2 + max(clearance, net.rules.clearance) + width // 2 + p.safety
            for x, y in rp.vias:
                for layer in range(grid.layers):
                    cells += grid.disc_cells(layer, x, y, r_via)
            path.claims[key] = cells
            routed = self.routed[key]
            for idx in cells:
                cur = owners[idx]
                if cur == 0:
                    owners[idx] = net.code
                    routed[idx] = path.pid
                elif cur != net.code and cur != BLOCKED:
                    # overlaps another net's zone: blocked for everyone. It stays
                    # rip-up-able only if that other zone was routed copper too
                    # (routed[idx] already names a path); fixed copper underneath
                    # means ripping this path would not free the cell.
                    owners[idx] = BLOCKED
        r_hole = rp.via_drill // 2 + p.hole_to_hole + p.max_via_drill // 2
        for x, y in rp.vias:
            path.via_cells += grid.disc_cells(0, x, y, r_hole)
        for idx in path.via_cells:
            p.via_block[idx] = 1

    def _rebuild_maps(self) -> None:
        """Fixed copper plus every surviving path, from scratch."""
        for key, owners in self.p.owners.items():
            owners[:] = self.fixed[key]
            self.routed[key][:] = array("i", [0]) * self.grid.size
        self.p.via_block[:] = self.fixed_via_block
        for pid in sorted(self.paths):
            path = self.paths[pid]
            path.claims = {}
            path.via_cells = []
            self._claim(path)

    # ---- routing one connection ------------------------------------------

    def _key(self, conn: Connection) -> Tuple[int, int]:
        net = self.p.nets[conn.net]
        return (conn.width or net.rules.width, net.rules.clearance)

    def _search(self, conn: Connection, via_cost: int, cap: int, soft: bool, cancelled):
        net = self.p.nets[conn.net]
        owners = self.p.owners[self._key(conn)]
        a_cells, a_anchors = self._component(conn.net, conn.a)
        b_cells, b_anchors = self._component(conn.net, conn.b)
        if not a_cells or not b_cells:
            return None
        if len(a_cells) > len(b_cells):
            a_cells, b_cells, b_anchors = b_cells, a_cells, a_anchors
        # pad cells inside another net's clearance zone would put the track end
        # too close to that net; only use them when nothing else is left
        goals = {c for c in b_cells if owners[c] in (0, net.code)} or b_cells
        sources = {c for c in a_cells if owners[c] in (0, net.code)} or a_cells
        width = conn.width or net.rules.width
        # cells to check around a via centre: the barrel beyond the track half
        # width, plus one cell because the check samples cell centres
        via_reach = max(0, int(math.ceil((net.rules.via_diameter - width) / 2 / self.grid.pitch))) + 1
        kwargs = {}
        if soft:
            kwargs = {"routed": self.routed[self._key(conn)],
                      "rippable": lambda pid: self._rippable(pid, conn),
                      "rip_penalty": RIP_PENALTY}
        return astar.route(self.grid, owners, self.p.via_block, net.code, sources, goals, b_anchors,
                           self.horizontal, via_cost, self.opts.allow_vias, via_reach, cap,
                           self.opts.turn_cost, cancelled, routable=self.routable, **kwargs)

    def _blockers(self, conn: Connection, cells: List[int]) -> Set[int]:
        """Paths of other nets that a soft route runs through: along its cells
        and, where it changes layer, under the via barrel on every layer."""
        routed = self.routed[self._key(conn)]
        grid = self.grid
        net = self.p.nets[conn.net]
        width = conn.width or net.rules.width
        reach = max(0, int(math.ceil((net.rules.via_diameter - width) / 2 / grid.pitch))) + 1
        spots = list(cells)
        for k in range(1, len(cells)):
            if cells[k] // grid.plane != cells[k - 1] // grid.plane:
                _, cx, cy = grid.unpack(cells[k])
                for dx in range(-reach, reach + 1):
                    for dy in range(-reach, reach + 1):
                        if dx * dx + dy * dy <= reach * reach and grid.inside(cx + dx, cy + dy):
                            for layer in range(grid.layers):
                                spots.append(grid.index(layer, cx + dx, cy + dy))
        out: Set[int] = set()
        for idx in spots:
            pid = routed[idx]
            if pid and pid in self.paths and self.paths[pid].conn.net != conn.net:
                out.add(pid)
        return out

    def _rippable(self, pid: int, for_conn: Connection) -> bool:
        path = self.paths.get(pid)
        if path is None or path.paired:
            return False
        if path.conn.net == for_conn.net:
            return True                       # own net's copper is never in the way
        key = (path.conn.net, path.conn.a, path.conn.b)
        return self.rips.get(key, 0) < self.opts.rip_limit

    def _commit(self, conn: Connection, cells: List[int], on_path) -> _Path:
        net = self.p.nets[conn.net]
        owners = self.p.owners[self._key(conn)]
        own_cells = set(cells)
        cells = _smooth(self.grid, cells, lambda idx: idx in own_cells or owners[idx] in (0, net.code))
        segments, vias = _simplify(self.grid, cells)
        segments = _with_pad_entries(self.grid, net, cells, segments)
        rp = RoutedPath(net.code, conn.width or net.rules.width, segments, vias, net.rules.via_diameter,
                        net.rules.via_drill, pid=self.next_pid)
        self.next_pid += 1
        path = _Path(rp.pid, conn, rp, cells)
        self.paths[rp.pid] = path
        self._claim(path)
        self.parent[conn.net][self._find(conn.net, conn.a)] = self._find(conn.net, conn.b)
        if on_path:
            on_path(rp)
        return path

    def _rip(self, pids: List[int], on_remove) -> List[Connection]:
        conns = []
        for pid in pids:
            path = self.paths.pop(pid, None)
            if path is None:
                continue
            conns.append(path.conn)
            key = (path.conn.net, path.conn.a, path.conn.b)
            self.rips[key] = self.rips.get(key, 0) + 1
            if on_remove:
                on_remove(pid)
        for code in {c.net for c in conns}:
            self._rebuild_union(code)
        self._rebuild_maps()
        return conns

    # ---- differential pairs ----------------------------------------------

    def _exit_of(self, code: int, cluster: int) -> Optional[int]:
        """A pad exit cell of a cluster (the cell a route starts from)."""
        net = self.p.nets[code]
        cells = net.clusters[cluster].cells
        for c in cells:
            if c in net.endpoints:
                return c
        return next(iter(cells), None)

    def _try_pair(self, ca: Connection, cb: Connection, via_cost: int, cap: int, on_path, cancelled) -> bool:
        """Route two connections of a differential pair as one coupled track:
        a centreline as wide as both tracks and their gap is searched, then
        split into the two tracks offset to either side, each joined to its
        own pad exits. Falls back to separate routing when the pair cannot
        start or end side by side."""
        p, grid = self.p, self.grid
        na, nb = p.nets[ca.net], p.nets[cb.net]
        self.pair_log = getattr(self, 'pair_log', [])
        if self._find(ca.net, ca.a) == self._find(ca.net, ca.b) or self._find(cb.net, cb.a) == self._find(cb.net, cb.b):
            self.pair_log.append((na.name, 'already joined'))
            return False
        # match the ends: B's clusters that share footprints with A's
        a1, a2 = na.clusters[ca.a], na.clusters[ca.b]
        b1, b2 = nb.clusters[cb.a], nb.clusters[cb.b]
        if not (a1.refs & b1.refs) and (a1.refs & b2.refs):
            b1, b2 = b2, b1
            cb_a, cb_b = cb.b, cb.a
        else:
            cb_a, cb_b = cb.a, cb.b
        ea1, ea2 = self._exit_of(ca.net, ca.a), self._exit_of(ca.net, ca.b)
        eb1, eb2 = self._exit_of(cb.net, cb_a), self._exit_of(cb.net, cb_b)
        if None in (ea1, ea2, eb1, eb2):
            self.pair_log.append((na.name, 'no exits'))
            return False
        la, xa1, ya1 = grid.unpack(ea1)
        lb, xb1, yb1 = grid.unpack(eb1)
        la2, xa2, ya2 = grid.unpack(ea2)
        lb2, xb2, yb2 = grid.unpack(eb2)
        if la != lb or la2 != lb2:
            self.pair_log.append((na.name, 'exits on different layers'))
            return False
        w, gap = na.rules.width, na.pair_gap
        W = 2 * w + gap
        key = (W, na.rules.clearance)
        owners = p.owners.get(key)
        if owners is None:
            self.pair_log.append((na.name, 'no owner map for pair width'))
            return False
        d = (w + gap) / 2.0

        span = math.hypot(xa2 - xa1, ya2 - ya1)          # cells between the two ends
        if span * grid.pitch < 3_000_000:
            self.pair_log.append((na.name, 'ends closer than 3 mm: routed separately'))
            return False
        walk = max(1, min(int(4_000_000 / grid.pitch), int(span * 0.45)))

        def starts(xa, ya, xb, yb, layer, code, cell):
            """Midpoint cells between the two exits, walked outward along the
            escape direction, so the pair can converge after leaving the pins."""
            ex, ey, px, py, _ = p.nets[code].endpoints.get(cell, (grid.nm_x(xa), grid.nm_y(ya), grid.nm_x(xa), grid.nm_y(ya), 0))
            dx, dy = grid.nm_x(xa) - px, grid.nm_y(ya) - py
            norm = math.hypot(dx, dy) or 1.0
            ux, uy = dx / norm, dy / norm
            out = []
            # walk out of the pin field (up to 4 mm, never past the middle);
            # one or two cells either side too, since the midpoint of two
            # exits need not be a cell centre. Each cell comes with its k.
            for k in range(0, walk):
                for lateral in (0, 1, -1, 2, -2):
                    mx = int(round((xa + xb) / 2 + ux * k - uy * lateral))
                    my = int(round((ya + yb) / 2 + uy * k + ux * lateral))
                    if grid.inside(mx, my):
                        out.append((k, grid.index(layer, mx, my)))
            return out

        def usable(cands):
            return [(k, c) for k, c in cands if owners[c] in (0, ca.net, cb.net)]

        s_list = usable(starts(xa1, ya1, xb1, yb1, la, ca.net, ea1))
        g_list = usable(starts(xa2, ya2, xb2, yb2, la2, ca.net, ea2))
        if not s_list or not g_list:
            self.pair_log.append((na.name, f'no coupled start/goal (starts {len(s_list)}, goals {len(g_list)})'))
            return False
        # couple as early as possible: starting further out costs extra, and
        # only the nearest usable goal rows are offered
        s_costs = {c: k * astar.STRAIGHT * 3 for k, c in s_list}
        kmin = min(k for k, _ in g_list)
        g_cells = {c for k, c in g_list if k <= kmin + 2}
        s_cells = set(s_costs)
        anchors = [grid.unpack(c)[1:] for c in list(g_cells)[:1]]
        cells = astar.route(grid, owners, p.via_block, ca.net, s_cells, g_cells, anchors,
                            self.horizontal, via_cost, False, 0, cap, self.opts.turn_cost, cancelled,
                            also_ok=cb.net, source_costs=s_costs, routable=self.routable)
        if not cells or len(cells) < 2:
            self.pair_log.append((na.name, 'no coupled path'))
            return False
        own_cells = set(cells)
        cells = _smooth(grid, cells, lambda idx: idx in own_cells or owners[idx] in (0, ca.net, cb.net))
        segments, _ = _simplify(grid, cells)
        if not segments:
            return False
        points = [(segments[0][1], segments[0][2])] + [(sg[3], sg[4]) for sg in segments]
        layer = segments[0][0]
        # which side of the centreline each net runs on, decided at the start
        # and checked at the end (a twist would need a crossing)
        def side_of(px, py, i):
            ux, uy = points[i + 1][0] - points[i][0], points[i + 1][1] - points[i][1]
            vx, vy = px - points[i][0], py - points[i][1]
            return 1 if ux * vy - uy * vx > 0 else -1
        sa = side_of(grid.nm_x(xa1), grid.nm_y(ya1), 0)
        sa_end = side_of(grid.nm_x(xa2), grid.nm_y(ya2), len(points) - 2)
        if sa != sa_end:
            self.pair_log.append((na.name, 'pair would cross'))
            return False
        paths = []
        for net, conn, side, e1, e2, cl_a, cl_b in ((na, ca, sa, ea1, ea2, ca.a, ca.b),
                                                   (nb, cb, -sa, eb1, eb2, cb_a, cb_b)):
            poly = _offset_polyline(points, d, side)
            segs = []
            for end_cell, at_start in ((e1, True), (e2, False)):
                ex, ey, px, py, sw = net.endpoints.get(end_cell, (None,) * 5)
                l_, cx, cy = grid.unpack(end_cell)
                gx, gy = grid.nm_x(cx), grid.nm_y(cy)
                entry = []
                if ex is not None:
                    if (ex, ey) != (px, py) and (ex, ey) != (gx, gy):
                        entry += [(layer, px, py, ex, ey, sw), (layer, ex, ey, gx, gy, sw)]
                    elif (px, py) != (gx, gy):
                        entry.append((layer, px, py, gx, gy, sw))
                join_to = poly[0] if at_start else poly[-1]
                if (gx, gy) != join_to:
                    # straight on along the escape, then a 45-degree step onto
                    # the coupled run (a designer's dog-leg, not a long slant)
                    if ex is not None and (gx, gy) != (px, py):
                        ux, uy = gx - px, gy - py
                    else:
                        ux, uy = join_to[0] - gx, join_to[1] - gy
                    norm = math.hypot(ux, uy) or 1.0
                    ux, uy = ux / norm, uy / norm
                    along = (join_to[0] - gx) * ux + (join_to[1] - gy) * uy
                    perp = math.hypot((join_to[0] - gx) - along * ux, (join_to[1] - gy) - along * uy)
                    straight = along - perp
                    if straight > grid.pitch:
                        qx, qy = int(round(gx + ux * straight)), int(round(gy + uy * straight))
                        entry.append((layer, gx, gy, qx, qy, w))
                        entry.append((layer, qx, qy, join_to[0], join_to[1], w))
                    else:
                        entry.append((layer, gx, gy, join_to[0], join_to[1], w))
                if at_start:
                    segs = entry + segs
                else:
                    segs = segs + [(l, x2, y2, x1, y1, ww) for l, x1, y1, x2, y2, ww in reversed(entry)]
                if at_start:
                    segs += [(layer, poly[i][0], poly[i][1], poly[i + 1][0], poly[i + 1][1], w) for i in range(len(poly) - 1)]
            rp = RoutedPath(net.code, w, _merge_collinear(segs), [], net.rules.via_diameter, net.rules.via_drill,
                            pid=self.next_pid)
            self.next_pid += 1
            paths.append((rp, conn, cl_a, cl_b))
        # the two halves must keep their clearance from each other everywhere
        # (joins and mitred corners can pinch); otherwise route them apart
        need = na.rules.clearance + w
        for sa_ in paths[0][0].segments:
            for sb_ in paths[1][0].segments:
                if _segment_distance(sa_[1:5], sb_[1:5]) < need:
                    self.pair_log.append((na.name, 'halves would pinch: routed separately'))
                    self.next_pid -= 2
                    return False
        for rp, conn, cl_a, cl_b in paths:
            path = _Path(rp.pid, conn, rp, cells, paired=True)
            self.paths[rp.pid] = path
            self._claim(path)
            self.parent[conn.net][self._find(conn.net, cl_a)] = self._find(conn.net, cl_b)
            if on_path:
                on_path(rp)
        return True

    def _try(self, conn: Connection, via_cost: int, cap: int, on_path, cancelled) -> bool:
        if self._find(conn.net, conn.a) == self._find(conn.net, conn.b):
            return True                        # already joined through other paths
        cells = self._search(conn, via_cost, cap, False, cancelled)
        if not cells:
            return False
        self._commit(conn, cells, on_path)
        return True

    def _why_failed(self, conn: Connection) -> dict:
        """What surrounds a failed connection's ends: how much room there is
        and which nets (or fixed copper) own the cells around each exit."""
        p, grid = self.p, self.grid
        net = p.nets[conn.net]
        own = p.owners[self._key(conn)]
        ends = []
        for cluster in (conn.a, conn.b):
            cell = self._exit_of(conn.net, cluster)
            if cell is None:
                continue
            layer, cx, cy = grid.unpack(cell)
            around: Dict[str, int] = {}
            free = total = 0
            for dx in range(-5, 6):
                for dy in range(-5, 6):
                    if not grid.inside(cx + dx, cy + dy):
                        continue
                    total += 1
                    o = own[grid.index(layer, cx + dx, cy + dy)]
                    if o in (0, net.code):
                        free += 1
                    else:
                        name = "fixed copper / keepout" if o == BLOCKED else p.nets[o].name if o in p.nets else f"net {o}"
                        around[name] = around.get(name, 0) + 1
            ends.append({"refs": sorted(net.clusters[cluster].refs),
                         "at_mm": [round(grid.nm_x(cx) / 1e6, 3), round(grid.nm_y(cy) / 1e6, 3)],
                         "layer": p.layers[layer].name,
                         "free_cells_around": f"{free}/{total}",
                         "blocked_by": dict(sorted(around.items(), key=lambda kv: -kv[1])[:5])})
        return {"net": net.name, "width_mm": round((conn.width or net.rules.width) / 1e6, 3), "ends": ends}

    # ---- fanout vias ------------------------------------------------------

    def _fanout_via(self, code: int, cell: int) -> Optional[RoutedPath]:
        """A stub from the pad through its exit cell to a via that ties the
        pad to the net's plane: straight out along the escape first, else the
        nearest spot within 1.5 mm where the barrel and the run to it fit."""
        p, grid = self.p, self.grid
        net = p.nets[code]
        own = p.owners[net.rules.key]
        ex, ey, px, py, stub_w = net.endpoints[cell]
        layer, ecx, ecy = grid.unpack(cell)
        gx, gy = grid.nm_x(ecx), grid.nm_y(ecy)
        reach = max(0, int(math.ceil((net.rules.via_diameter - net.rules.width) / 2 / grid.pitch))) + 1
        dx, dy = gx - px, gy - py
        norm = math.hypot(dx, dy) or 1.0
        step = (dx / norm, dy / norm)

        def fits(vx: int, vy: int) -> bool:
            if not grid.inside(vx, vy) or p.via_block[vy * grid.w + vx]:
                return False
            for ddx in range(-reach, reach + 1):
                for ddy in range(-reach, reach + 1):
                    if ddx * ddx + ddy * ddy > reach * reach:
                        continue
                    if not grid.inside(vx + ddx, vy + ddy):
                        return False
                    for li in range(grid.layers):
                        if own[grid.index(li, vx + ddx, vy + ddy)] not in (0, code):
                            return False
            for i in grid.segment_cells(layer, gx, gy, grid.nm_x(vx), grid.nm_y(vy), grid.pitch // 2):
                if own[i] not in (0, code):
                    return False
            return True

        candidates = [(ecx + int(round(step[0] * k)), ecy + int(round(step[1] * k))) for k in range(0, 6)]
        radius = max(2, int(1_500_000 / grid.pitch))
        ring = sorted(((ddx * ddx + ddy * ddy, ecx + ddx, ecy + ddy)
                       for ddx in range(-radius, radius + 1) for ddy in range(-radius, radius + 1)
                       if 0 < ddx * ddx + ddy * ddy <= radius * radius))
        candidates += [(x, y) for _, x, y in ring]
        seen = set()
        for vx, vy in candidates:
            if (vx, vy) in seen:
                continue
            seen.add((vx, vy))
            if fits(vx, vy):
                break
        else:
            return None
        vxn, vyn = grid.nm_x(vx), grid.nm_y(vy)
        segments = []
        if (ex, ey) != (px, py) and (ex, ey) != (gx, gy):
            segments += [(layer, px, py, ex, ey, stub_w), (layer, ex, ey, gx, gy, stub_w)]
        else:
            segments.append((layer, px, py, gx, gy, stub_w))
        if (vxn, vyn) != (gx, gy):
            segments.append((layer, gx, gy, vxn, vyn, stub_w))
        rp = RoutedPath(code, net.rules.width, _merge_collinear(segments), [(vxn, vyn)],
                        net.rules.via_diameter, net.rules.via_drill, pid=self.next_pid)
        self.next_pid += 1
        fake = Connection(code, 0, 0, 0)
        path = _Path(rp.pid, fake, rp, [cell])
        self._claim(path)                       # vias and stubs become obstacles for later fanouts
        return rp

    def _stitch_via(self, code: int, cx: int, cy: int) -> Optional[RoutedPath]:
        """A lone via of a pour net at a grid spot, if the barrel and hole fit
        on every layer; the refilled pours connect it on both sides."""
        p, grid = self.p, self.grid
        net = p.nets[code]
        own = p.owners[net.rules.key]
        reach = max(0, int(math.ceil((net.rules.via_diameter - net.rules.width) / 2 / grid.pitch))) + 1
        if not grid.inside(cx, cy) or p.via_block[cy * grid.w + cx]:
            return None
        for ddx in range(-reach, reach + 1):
            for ddy in range(-reach, reach + 1):
                if ddx * ddx + ddy * ddy > reach * reach:
                    continue
                if not grid.inside(cx + ddx, cy + ddy):
                    return None
                for li in range(grid.layers):
                    if own[grid.index(li, cx + ddx, cy + ddy)] not in (0, code):
                        return None
        x, y = grid.nm_x(cx), grid.nm_y(cy)
        rp = RoutedPath(code, net.rules.width, [], [(x, y)], net.rules.via_diameter, net.rules.via_drill,
                        pid=self.next_pid)
        self.next_pid += 1
        path = _Path(rp.pid, Connection(code, 0, 0, 0), rp, [grid.index(0, cx, cy)])
        self._claim(path)
        return rp

    # ---- the whole run --------------------------------------------------

    def run(self, progress: Optional[ProgressFn] = None, on_path: Optional[PathFn] = None,
            on_remove: Optional[RemoveFn] = None, cancelled: Optional[Callable[[], bool]] = None) -> RouteResult:
        opts = self.opts
        result = RouteResult()
        started = time.time()
        # fine-pitch escapes first (they have the least room), then shortest first
        queue = sorted(self.p.connections, key=lambda c: (c.priority, c.estimate))
        total = len(queue)
        failed: List[Connection] = []
        done = 0

        def report(name):
            if progress:
                progress(done, total, len(self.paths), len(failed), name)

        def stop():
            return bool(cancelled and cancelled())

        # 1. plain pass; a differential pair's two connections go together
        partners = {}
        for conn in queue:
            if conn.pair:
                partners.setdefault(conn.pair, []).append(conn)
        handled = set()
        self.pairs_routed = 0
        for conn in queue:
            if stop():
                break
            if id(conn) in handled:
                continue
            mates = partners.get(conn.pair, []) if conn.pair else []
            if len(mates) == 2:
                ca, cb = mates
                handled.add(id(ca)); handled.add(id(cb))
                if self._try_pair(ca, cb, opts.via_cost, opts.max_expansions, on_path, cancelled):
                    self.pairs_routed += 1
                    done += 2
                    report(self.p.nets[ca.net].name)
                    continue
                for c in (ca, cb):                 # fall back to separate routes
                    if not self._try(c, opts.via_cost, opts.max_expansions, on_path, cancelled):
                        failed.append(c)
                    done += 1
                report(self.p.nets[ca.net].name)
                continue
            if not self._try(conn, opts.via_cost, opts.max_expansions, on_path, cancelled):
                failed.append(conn)
            done += 1
            report(self.p.nets[conn.net].name)

        # 2. rip-up rounds
        rounds = opts.rip_rounds if opts.rip_up else 0
        for _ in range(rounds):
            if not failed or stop():
                break
            still: List[Connection] = []
            progressed = False
            for conn in failed:
                if stop():
                    still.append(conn)
                    continue
                if self._find(conn.net, conn.a) == self._find(conn.net, conn.b):
                    continue
                cells = self._search(conn, opts.via_cost, opts.max_expansions * 2, True, cancelled)
                if not cells:
                    still.append(conn)
                    continue
                blockers = sorted(self._blockers(conn, cells))
                if len(blockers) > MAX_BLOCKERS:
                    still.append(conn)
                    continue
                ripped = self._rip(blockers, on_remove)
                result.ripped += len(ripped)
                if self._try(conn, opts.via_cost, opts.max_expansions * 2, on_path, cancelled):
                    progressed = True
                else:
                    still.append(conn)
                for other in ripped:
                    if not self._try(other, opts.via_cost, opts.max_expansions, on_path, cancelled):
                        still.append(other)
                report(self.p.nets[conn.net].name)
            failed = still
            if not progressed:
                break

        # 3. last chance with a bigger budget and cheaper vias
        if failed and opts.retry_failed and not stop():
            still = []
            for conn in failed:
                if not self._try(conn, max(5, opts.via_cost // 3), opts.max_expansions * 3, on_path, cancelled):
                    still.append(conn)
                report(self.p.nets[conn.net].name)
            failed = still

        # 4. fanout vias for pour nets, in whatever room is left
        fanout_paths: List[RoutedPath] = []
        if not stop():
            for code, cell in self.p.fanout:
                rp = self._fanout_via(code, cell)
                if rp is not None:
                    fanout_paths.append(rp)
                    if on_path:
                        on_path(rp)

        # 5. stitching vias on the pour nets, wherever they still fit
        stitch_paths: List[RoutedPath] = []
        if not stop():
            for code, spots in self.p.stitch.items():
                for cx, cy in spots:
                    rp = self._stitch_via(code, cx, cy)
                    if rp is not None:
                        stitch_paths.append(rp)
                        if on_path:
                            on_path(rp)

        result.cancelled = stop()
        result.failed = [c for c in failed if self._find(c.net, c.a) != self._find(c.net, c.b)]
        result.failed_detail = [self._why_failed(c) for c in result.failed]
        result.paths = [self.paths[pid].path for pid in sorted(self.paths)] + fanout_paths + stitch_paths
        result.stitched = len(stitch_paths)
        result.routed = len(self.paths)
        result.fanout = len(fanout_paths)
        result.pairs = getattr(self, "pairs_routed", 0)
        result.pair_log = getattr(self, "pair_log", [])
        result.seconds = time.time() - started
        return result


def run(problem: RoutingProblem, progress: Optional[ProgressFn] = None,
        on_path: Optional[PathFn] = None, cancelled: Optional[Callable[[], bool]] = None,
        on_remove: Optional[RemoveFn] = None) -> RouteResult:
    return Router(problem).run(progress=progress, on_path=on_path, on_remove=on_remove, cancelled=cancelled)
